# OpenCV Haar Cascade

## モデル

* [OpenCV Haar Cascade](https://github.com/opencv/opencv/tree/4.5.5)
  * [haarcascade_frontalface_default.xml](https://raw.githubusercontent.com/opencv/opencv/4.5.5/data/haarcascades/haarcascade_frontalface_default.xml)  

## 著作権/ライセンス

* Copyright (c) 2015-2021 OpenCV Foundation  
* [Apache License Version 2.0](https://github.com/opencv/opencv/blob/4.5.5/LICENSE)  
